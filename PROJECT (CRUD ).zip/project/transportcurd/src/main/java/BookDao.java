//BookDao.java


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BookDao {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Book b){
		int status=0;
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Booking201(id,t1,t2,t3,t4) values (crud.nextval,?,?,?,?)");
			ps.setString(1,b.getT1());
			ps.setString(2,b.getT2());
			ps.setString(3,b.getT3());
			ps.setString(4,b.getT4());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(Book b){
		int status=0;
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update Booking201 set t1=?,t2=?,t3=?,t4=? where id=?");
			ps.setString(1,b.getT1());
			ps.setString(2,b.getT2());
			ps.setString(3,b.getT3());
			ps.setString(4,b.getT4());
			ps.setInt(5,b.getId());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int id){
		int status=0;
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from Booking201 where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static Book getEmployeeById(int id){
		Book e=new Book();
		
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Booking201 where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				e.setId(rs.getInt(1));
				e.setT1(rs.getString(2));
				e.setT2(rs.getString(3));
				e.setT3(rs.getString(4));
				e.setT4(rs.getString(5));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	public static List<Book> getAllEmployees(){
		List<Book> list=new ArrayList<Book>();
		
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Booking201");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book e=new Book();
				e.setId(rs.getInt(1));
				e.setT1(rs.getString(2));
				e.setT2(rs.getString(3));
				e.setT3(rs.getString(4));
				e.setT4(rs.getString(5));
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
