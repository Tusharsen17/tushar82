

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Editcontact
 */
@WebServlet("/Editcontact")
public class Editcontact extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Update ContactDetails</h1>");
		String sid=request.getParameter("idc");
		int idc=Integer.parseInt(sid);
		
		contact c=ContactDao.getEmployeeById(idc);
		
		out.print("<form action='Editcontact1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='idc' value='"+c.getIdc()+"'/></td></tr>");
		out.print("<tr><td>Name:</td><td><input type='text' name='name1' value='"+c.getName1()+"'/></td></tr>");
		out.print("<tr><td>Email:</td><td><input type='text' name='email1' value='"+c.getEmail1()+"'/></td></tr>");
		out.print("<tr><td>Phoneno:</td><td><input type='text' name='phoneno1' value='"+c.getPhoneno1()+"'/></td></tr>");
		out.print("<tr><td>Contact:</td><td><input type='text' name='contact' value='"+c.getContact()+"'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		
		out.close();
	}

}
