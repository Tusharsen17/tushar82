

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ContactDao
 */
@WebServlet("/ContactDao")
public class ContactDao extends HttpServlet {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(contact c){
		int status=0;
		try{
			Connection con=ContactDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into contact201(idc,name1,email1,phoneno1,contact) values (crud91.nextval,?,?,?,?)");
			ps.setString(1,c.getName1());
			ps.setString(2,c.getEmail1());
			ps.setString(3,c.getPhoneno1());
			ps.setString(4,c.getContact());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(contact c){
		int status=0;
		try{
			Connection con=BookDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update contact201 set name1=?,email1=?,phoneno1=?,contact=? where idc=?");
			ps.setString(1,c.getName1());
			ps.setString(2,c.getEmail1());
			ps.setString(3,c.getPhoneno1());
			ps.setString(4,c.getContact());
			ps.setInt(5,c.getIdc());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int idc){
		int status=0;
		try{
			Connection con=ContactDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from contact201 where idc=?");
			ps.setInt(1,idc);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static contact getEmployeeById(int idc){
		contact c=new contact();
		
		try{
			Connection con=ContactDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from contact201 where idc=?");
			ps.setInt(1,idc);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				c.setIdc(rs.getInt(1));
				c.setName1(rs.getString(2));
				c.setEmail1(rs.getString(3));
				c.setPhoneno1(rs.getString(4));
				c.setContact(rs.getString(5));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return c;
	}
	public static List<contact> getAllEmployees(){
		List<contact> list=new ArrayList<contact>();
		
		try{
			Connection con=ContactDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from contact201");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				contact c=new contact();
				c.setIdc(rs.getInt(1));
				c.setName1(rs.getString(2));
				c.setEmail1(rs.getString(3));
				c.setPhoneno1(rs.getString(4));
				c.setContact(rs.getString(5));
				list.add(c);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
