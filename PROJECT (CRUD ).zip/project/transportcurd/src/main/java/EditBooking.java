
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditBooking
 */
@WebServlet("/EditBooking")
public class EditBooking extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Update BookDetails</h1>");
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		Book b=BookDao.getEmployeeById(id);
		
		out.print("<form action='EditBooking2' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+b.getId()+"'/></td></tr>");
		out.print("<tr><td>Name:</td><td><input type='text' name='t1' value='"+b.getT1()+"'/></td></tr>");
		out.print("<tr><td>Pickup_Location:</td><td><input type='text' name='t2' value='"+b.getT2()+"'/></td></tr>");
		out.print("<tr><td>Drop_Location:</td><td><input type='text' name='t3' value='"+b.getT3()+"'/></td></tr>");
		out.print("<tr><td>When:</td><td><input type='text' name='t4' value='"+b.getT4()+"'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		
		out.close();
	}
}
