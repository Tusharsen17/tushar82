

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationDao
 */
@WebServlet("/RegistrationDao")
public class RegistrationDao extends HttpServlet {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Reg r){
		int status=0;
		try{
			Connection con=RegistrationDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Regi(idr,name,email,phoneno,password,address) values (crud81.nextval,?,?,?,?,?)");
			ps.setString(1,r.getName());
			ps.setString(2,r.getEmail());
			ps.setString(3,r.getPhoneno());
			ps.setString(4,r.getPassword());
			ps.setString(5, r.getAddress());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(Reg r){
		int status=0;
		try{
			Connection con=RegistrationDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update Regi set name=?,email=?,phoneno=?,password=?,address=? where idr=?");
			ps.setString(1,r.getName());
			ps.setString(2,r.getEmail());
			ps.setString(3,r.getPhoneno());
			ps.setString(4,r.getPassword());
			ps.setString(5,r.getAddress());
			ps.setInt(6,r.getIdr());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int idr){
		int status=0;
		try{
			Connection con=RegistrationDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from Regi where idr=?");
			ps.setInt(1,idr);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static Reg getEmployeeById(int idr){
		Reg r=new Reg();
		
		try{
			Connection con=RegistrationDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Regi where idr=?");
			ps.setInt(1,idr);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				r.setIdr(rs.getInt(1));
				r.setName(rs.getString(2));
				r.setEmail(rs.getString(3));
				r.setPhoneno(rs.getString(4));
				r.setPassword(rs.getString(5));
				r.setAddress(rs.getString(6));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return r;
	}
	public static List<Reg> getAllEmployees(){
		List<Reg> list=new ArrayList<Reg>();
		
		try{
			Connection con=RegistrationDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Regi");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Reg r=new Reg();
				r.setIdr(rs.getInt(1));
				r.setName(rs.getString(2));
				r.setEmail(rs.getString(3));
				r.setPhoneno(rs.getString(4));
				r.setPassword(rs.getString(5));
				r.setAddress(rs.getString(6));
				list.add(r);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
