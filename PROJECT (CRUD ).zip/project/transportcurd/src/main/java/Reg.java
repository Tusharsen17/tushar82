//create table Regi(idr number,name varchar2(30),email varchar2(30),phoneno varchar2(30),password varchar2(30),address varchar2(30))
//create sequence crud81 increment by 1 start with 1;
public class Reg {
private int idr;
private String name,email,phoneno,password,address;
public int getIdr() {
	return idr;
}
public void setIdr(int idr) {
	this.idr = idr;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
