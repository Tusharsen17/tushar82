

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditReg1
 */
@WebServlet("/EditReg1")
public class EditReg1 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("idr");
		int idr=Integer.parseInt(sid);
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String phoneno=request.getParameter("phoneno");
		String password=request.getParameter("password");
		String address=request.getParameter("address");
		
		Reg r=new Reg();
		r.setIdr(idr);
		r.setName(name);
		r.setEmail(password);
		r.setPhoneno(email);
		r.setPassword(password);
		r.setAddress(address);
		
		int status=RegistrationDao.update(r);
		if(status>0){
			response.sendRedirect("ViewRegisration");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}
}
