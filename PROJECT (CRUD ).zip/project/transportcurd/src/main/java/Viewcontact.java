

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Viewcontact
 */
@WebServlet("/Viewcontact")
public class Viewcontact extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='contact.html'>goto feedback page</a>");
		out.println("<h1>Feedback List</h1>");
		
		List<contact> list=ContactDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Phonenumber</th><th>Feedback</th><th>Edit</th><th>Delete</th></tr>");
		for(contact c:list){
			out.print("<tr><td>"+c.getIdc()+"</td><td>"+c.getName1()+"</td><td>"+c.getEmail1()+"</td><td>"+c.getPhoneno1()+"</td><td>"+c.getContact()+"</td><td><a href='Editcontact?idc="+c.getIdc()+"'>Edit</a></td><td><a href='Deletecontact?idc="+c.getIdc()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
