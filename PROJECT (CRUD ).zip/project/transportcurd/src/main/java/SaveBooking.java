
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveBooking
 */
@WebServlet("/SaveBooking")
public class SaveBooking extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String t1=request.getParameter("t1");
		String t2 =request.getParameter("t2");
		String t3=request.getParameter("t3");
		String t4=request.getParameter("t4");
		
		 Book b=new Book();
		b.setT1(t1);
		b.setT2(t2);
		b.setT3(t3);
		b.setT4(t4);
		
		int status=BookDao.save(b);
		if(status>0){
			//out.print("<p>Record saved successfully!</p>");
			request.getRequestDispatcher("Booking.html").include(request, response);
		}else{
			out.println("Sorry! unable to save record");
		}
		
		out.close();
	}
}
