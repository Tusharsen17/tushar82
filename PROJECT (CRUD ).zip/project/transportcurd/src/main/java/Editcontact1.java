

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Editcontact1
 */
@WebServlet("/Editcontact1")
public class Editcontact1 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("idc");
		int idc=Integer.parseInt(sid);
		String name=request.getParameter("name1");
		String email=request.getParameter("email1");
		String phoneno=request.getParameter("phoneno1");
		String contact=request.getParameter("contact");
		
		contact c=new contact();
		c.setIdc(idc);
		c.setName1(name);
		c.setEmail1(email);
		c.setPhoneno1(phoneno);
		c.setContact(contact);
		
		int status=ContactDao.update(c);
		if(status>0){
			response.sendRedirect("Viewcontact");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
