
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditBooking2
 */
@WebServlet("/EditBooking2")
public class EditBooking2 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name=request.getParameter("t1");
		String password=request.getParameter("t2");
		String email=request.getParameter("t3");
		String country=request.getParameter("t4");
		
		Book b=new Book();
		b.setId(id);
		b.setT1(name);
		b.setT2(password);
		b.setT3(email);
		b.setT4(country);
		
		int status=BookDao.update(b);
		if(status>0){
			response.sendRedirect("ViewBook");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
