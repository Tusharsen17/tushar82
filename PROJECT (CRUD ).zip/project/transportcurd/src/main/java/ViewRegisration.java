

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewRegisration
 */
@WebServlet("/ViewRegisration")
public class ViewRegisration extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='contact.html'>Book Car</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Reg> list=RegistrationDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Phoneno</th><th>Password</th><th>Address<th>Edit</th><th>Delete</th></tr>");
		for(Reg r:list){
			out.print("<tr><td>"+r.getIdr()+"</td><td>"+r.getName()+"</td><td>"+r.getEmail()+"</td><td>"+r.getPhoneno()+"</td><td>"+r.getPassword()+"</td><td>"+r.getAddress()+"</td><td><a href='EditRegi?idr="+r.getIdr()+"'>Edit</a></td><td><a href='DeleteRegi?idr="+r.getIdr()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
