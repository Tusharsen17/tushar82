//Book.java
/*create table Booking201(id number,t1 varchar2(50),t2 varchar2(50),t3 varchar2(50),t4 varchar2(50));
 create sequence crud increment by 1 start with 1;*/

/*create table feedback201(id1 number,ft1 varchar2(30),ft2 varchar2(30),ft3 varchar2(30),ft4 varchar2(30));
create sequence crud21 increment by 1 start with 1;*/

public class Book {
private int id,id1;
private String t1,t2,t3,t4;
private String ft1,ft2,ft3,ft4;

public int getId1() {
	return id1;
}

public void setId1(int id1) {
	this.id1 = id1;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getT1() {
	return t1;
}

public void setT1(String t1) {
	this.t1 = t1;
}

public String getT2() {
	return t2;
}

public void setT2(String t2) {
	this.t2 = t2;
}

public String getT3() {
	return t3;
}

public void setT3(String t3) {
	this.t3 = t3;
}

public String getT4() {
	return t4;
}

public void setT4(String t4) {
	this.t4 = t4;
}

public String getFt1() {
	return ft1;
}

public void setFt1(String ft1) {
	this.ft1 = ft1;
}

public String getFt2() {
	return ft2;
}

public void setFt2(String ft2) {
	this.ft2 = ft2;
}

public String getFt3() {
	return ft3;
}

public void setFt3(String ft3) {
	this.ft3 = ft3;
}

public String getFt4() {
	return ft4;
}

public void setFt4(String ft4) {
	this.ft4 = ft4;
}

}
