
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewBook
 */
@WebServlet("/ViewBook")
public class ViewBook extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='Booking.html'>Book Car</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Book> list=BookDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>Name</th><th>Pickup_Location</th><th>Drop_Location</th><th>When</th><th>Edit</th><th>Delete</th></tr>");
		for(Book b:list){
			out.print("<tr><td>"+b.getId()+"</td><td>"+b.getT1()+"</td><td>"+b.getT2()+"</td><td>"+b.getT3()+"</td><td>"+b.getT4()+"</td><td><a href='EditBooking?id="+b.getId()+"'>edit</a></td><td><a href='DeleteBooking?id="+b.getId()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
