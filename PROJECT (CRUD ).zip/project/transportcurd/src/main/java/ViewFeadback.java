

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewFeadback
 */
@WebServlet("/ViewFeadback")
public class ViewFeadback extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='feedback.html'>feedback</a>");
		out.println("<h1>Feedback List</h1>");
		
		List<Book> list=feedbackDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Phonenumber</th><th>Feedback</th><th>Edit</th><th>Delete</th></tr>");
		for(Book b:list){
			out.print("<tr><td>"+b.getId1()+"</td><td>"+b.getFt1()+"</td><td>"+b.getFt2()+"</td><td>"+b.getFt3()+"</td><td>"+b.getFt4()+"</td><td><a href='EditFeedback1?id1="+b.getId1()+"'>edit</a></td><td><a href='Deletfeedback?id1="+b.getId1()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
