
import javax.servlet.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class feedbackDao
 */
@WebServlet("/feedbackDao")
public class feedbackDao extends HttpServlet {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Book b){
		int status=0;
		try{
			Connection con=feedbackDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into feedback201(id1,ft1,ft2,ft3,ft4) values (crud21.nextval,?,?,?,?)");
			ps.setString(1,b.getFt1());
			ps.setString(2,b.getFt2());
			ps.setString(3,b.getFt3());
			ps.setString(4,b.getFt4());	
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(Book b){
		int status=0;
		try{
			Connection con=feedbackDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update feedback201 set ft1=?,ft2=?,ft3=?,ft4=? where id1=?");
			ps.setString(1,b.getFt1());
			ps.setString(2,b.getFt2());
			ps.setString(3,b.getFt3());
			ps.setString(4,b.getFt4());
			ps.setInt(5,b.getId1());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int id1){
		int status=0;
		try{
			Connection con=feedbackDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from feedback201 where id1=?");
			ps.setInt(1,id1);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static Book getEmployeeById(int id1){
		Book e=new Book();
		
		try{
			Connection con=feedbackDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from feedback201 where id1=?");
			ps.setInt(1,id1);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				e.setId1(rs.getInt(1));
				e.setFt1(rs.getString(2));
				e.setFt2(rs.getString(3));
				e.setFt3(rs.getString(4));
				e.setFt4(rs.getString(5));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	public static List<Book> getAllEmployees(){
		List<Book> list=new ArrayList<Book>();
		
		try{
			Connection con=feedbackDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from feedback201");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book e=new Book();
				e.setId1(rs.getInt(1));
				e.setFt1(rs.getString(2));
				e.setFt2(rs.getString(3));
				e.setFt3(rs.getString(4));
				e.setFt4(rs.getString(5));
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
