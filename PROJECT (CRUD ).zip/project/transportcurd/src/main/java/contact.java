/*create table contact201(idc number,name1 varchar2(30),email varchar2(40),phoneno1 varchar2(30),contact varchar2(30))*/
//create sequence crud91 increment by 1 start with 1;
public class contact {
private String name1,email1,phoneno1,contact;
private int idc;
public String getName1() {
	return name1;
}
public void setName1(String name1) {
	this.name1 = name1;
}
public String getEmail1() {
	return email1;
}
public void setEmail1(String email1) {
	this.email1 = email1;
}
public String getPhoneno1() {
	return phoneno1;
}
public void setPhoneno1(String phoneno1) {
	this.phoneno1 = phoneno1;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public int getIdc() {
	return idc;
}
public void setIdc(int idc) {
	this.idc = idc;
}

}
